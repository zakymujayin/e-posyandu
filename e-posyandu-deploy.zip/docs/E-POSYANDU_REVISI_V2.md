# E-POSYANDU — DOKUMEN REVISI V2
**Revisi terhadap Dokumentasi Teknis V1 (E-POSYANDU_DOKUMENTASI_TEKNIS.md)**
**Tanggal: 25 Mei 2026**

---

## RINGKASAN REVISI

Ada **2 perubahan besar** dari dokumen teknis V1:

| No | Revisi | Dampak |
|----|--------|--------|
| 1 | **Perubahan sistem akun Posyandu** — dari akun individual per kader menjadi akun shared per posyandu | Perubahan arsitektur auth, database schema user, form registrasi, dan semua referensi ke "kader" |
| 2 | **Penambahan modul baru: Layanan Data Balita** — pencatatan penimbangan bulanan & riwayat imunisasi per anak balita | Tabel database baru, halaman baru, API baru, rekap data ke level desa |

---

## REVISI 1: PERUBAHAN SISTEM AKUN

### 1.1 Perubahan Konsep Akun

**SEBELUM (V1):**
- Setiap kader posyandu punya akun individual (email + password masing-masing)
- 1 posyandu bisa punya banyak akun kader
- Role: `KADER`

**SESUDAH (V2):**
- Setiap **posyandu** punya **1 akun shared** (username + password dipakai bersama oleh semua kader di posyandu itu)
- 1 posyandu = 1 akun saja
- Role: `POSYANDU`
- Semua kader di posyandu tersebut login menggunakan akun yang sama

**Role lain TIDAK berubah** — tetap 1 orang 1 akun individual:
- `PETUGAS_DESA` → 1 orang 1 akun
- `PETUGAS_KECAMATAN` → 1 orang 1 akun
- `PETUGAS_OPD` → 1 orang 1 akun
- `ADMIN_DPMD` → 1 orang 1 akun

### 1.2 Perubahan Daftar Role

**SEBELUM (V1):**
```
enum UserRole {
  KADER
  PETUGAS_DESA
  PETUGAS_KECAMATAN
  PETUGAS_OPD
  ADMIN_DPMD
}
```

**SESUDAH (V2):**
```
enum UserRole {
  POSYANDU              // ← ganti dari KADER
  PETUGAS_DESA
  PETUGAS_KECAMATAN
  PETUGAS_OPD
  ADMIN_DPMD
}
```

### 1.3 Perubahan Tabel `users` untuk Akun Posyandu

**SEBELUM (V1):**
Akun kader menyimpan data individual:
```
name: "Siti Aminah"         ← nama orang
email: "siti@example.com"
posyanduId: "uuid-posyandu"
```

**SESUDAH (V2):**
Akun posyandu menyimpan data unit:
```
name: "Posyandu Melati"     ← nama posyandu
email: "posyandu-melati@example.com" atau "melati001" (username)
noRegistrasi: "REG-2026-001" ← nomor registrasi posyandu (field BARU)
posyanduId: "uuid-posyandu"
desaId: "uuid-desa"         ← relasi ke desa
kecamatanId: "uuid-kecamatan" ← relasi ke kecamatan
```

### 1.4 Perubahan Schema Prisma — Tabel `users`

**Tambahkan field baru dan ubah komentar:**
```prisma
model User {
  id           String   @id @default(uuid())
  name         String                          // Untuk POSYANDU: nama posyandu. Untuk role lain: nama orang.
  email        String   @unique                // Untuk POSYANDU: bisa berupa username (misal: "melati001")
  password     String                          // bcrypt hashed. Untuk POSYANDU: dipakai bersama oleh kader.
  role         UserRole

  // === Field khusus role POSYANDU ===
  noRegistrasi String?  @unique @map("no_registrasi")  // BARU — Nomor registrasi posyandu (wajib untuk role POSYANDU)

  // === Relasi wilayah / unit kerja ===
  posyanduId   String?  @map("posyandu_id")   // untuk POSYANDU
  desaId       String?  @map("desa_id")       // untuk POSYANDU dan PETUGAS_DESA
  kecamatanId  String?  @map("kecamatan_id")  // untuk POSYANDU dan PETUGAS_KECAMATAN
  opdId        String?  @map("opd_id")        // untuk PETUGAS_OPD
  
  phone        String?
  isActive     Boolean  @default(true) @map("is_active")
  lastLoginAt  DateTime? @map("last_login_at")
  createdAt    DateTime @default(now()) @map("created_at")
  updatedAt    DateTime @updatedAt @map("updated_at")

  // ... relasi lainnya tetap sama
}
```

### 1.5 Perubahan Form Registrasi Akun Posyandu

**SEBELUM (V1) — Form tambah user kader:**
```
Nama         : [text, nama orang]
Email        : [text]
Password     : [text]
Posyandu     : [select, pilih posyandu]
```

**SESUDAH (V2) — Form tambah akun posyandu:**
```
Nama Posyandu       : [text, WAJIB]
No Registrasi       : [text, WAJIB, unik]
Desa                : [select, WAJIB — pilih dari master desa]
Kecamatan           : [auto-fill berdasarkan desa yang dipilih]
Username / Email    : [text, WAJIB, unik — bisa berupa username atau email]
Password            : [text, WAJIB]
```

**Catatan:** Kecamatan otomatis terisi saat admin memilih desa (karena desa sudah berelasi ke kecamatan di database).

### 1.6 Perubahan Template Import CSV

**SEBELUM (V1):**
```csv
nama,email,password,posyandu_id
Siti Aminah,siti@example.com,password123,uuid-posyandu
```

**SESUDAH (V2):**
```csv
nama_posyandu,no_registrasi,email,password,desa_id
Posyandu Melati,REG-2026-001,melati001,password123,uuid-desa
Posyandu Mawar,REG-2026-002,mawar001,password123,uuid-desa
```

**Catatan:** `posyandu_id` dan `kecamatan_id` tidak perlu di CSV karena:
- Record posyandu di tabel `posyandus` otomatis dicari/dibuat berdasarkan `nama_posyandu` + `desa_id`
- `kecamatan_id` diambil dari relasi `desa → kecamatan`

### 1.7 Dampak pada Seluruh Dokumen V1

Semua referensi berikut harus diganti:

| Sebelum (V1) | Sesudah (V2) |
|--------------|--------------|
| "Kader Posyandu" (sebagai role) | "Akun Posyandu" |
| "kader menginput pengajuan" | "posyandu menginput pengajuan" |
| `kaderId` di tabel `pengajuans` | `posyanduUserId` (tetap merujuk ke `users.id`, tapi sekarang itu akun posyandu) |
| Role `KADER` di enum | Role `POSYANDU` di enum |
| "Selamat datang, [Nama Kader]" | "Selamat datang, [Nama Posyandu]" |
| "Kader yang membuat pengajuan mendapat notifikasi" | "Akun posyandu yang membuat pengajuan mendapat notifikasi" |
| Redirect `KADER → /kader` | Redirect `POSYANDU → /posyandu` |
| Data scoping: `kaderId = session.user.id` | Data scoping: `posyanduUserId = session.user.id` |

### 1.8 Perubahan Halaman Dashboard Posyandu

**SEBELUM (V1):**
```
Selamat datang, Siti Aminah 👋
Posyandu: Posyandu Melati — Desa Sukamaju
```

**SESUDAH (V2):**
```
Selamat datang, Posyandu Melati 👋
Desa Sukamaju — Kecamatan Rangkasbitung
No. Registrasi: REG-2026-001
```

### 1.9 Perubahan Struktur Folder

**SEBELUM (V1):**
```
/app/(dashboard)/kader/
  page.tsx
  /ajukan/[opdId]/page.tsx
  /riwayat/page.tsx
```

**SESUDAH (V2):**
```
/app/(dashboard)/posyandu/
  page.tsx                         ← Dashboard (6 card OPD + menu balita)
  /ajukan/[opdId]/page.tsx         ← Form pengajuan
  /riwayat/page.tsx                ← Riwayat pengajuan
  /balita/                         ← MODUL BARU
    page.tsx                       ← Daftar data balita
    /tambah/page.tsx               ← Form tambah balita
    /[balitaId]/page.tsx           ← Detail & penimbangan bulanan
    /[balitaId]/imunisasi/page.tsx ← Riwayat imunisasi
```

### 1.10 Perubahan Permission Matrix

| Fitur | POSYANDU | PETUGAS_DESA | PETUGAS_KECAMATAN | PETUGAS_OPD | ADMIN_DPMD |
|-------|----------|--------------|-------------------|-------------|------------|
| Buat pengajuan baru | ✅ | ❌ | ❌ | ❌ | ❌ |
| Lihat pengajuan milik sendiri | ✅ | ✅ | ✅* | ✅* | ✅ |
| Input data balita | ✅ | ❌ | ❌ | ❌ | ❌ |
| Lihat rekap balita desa | ❌ | ✅ | ❌ | ❌ | ✅ |
| Lihat rekap balita kecamatan | ❌ | ❌ | ✅ | ❌ | ✅ |
| Verifikasi pengajuan | ❌ | ✅ | ❌ | ❌ | ❌ |
| Tolak pengajuan (desa) | ❌ | ✅ | ❌ | ❌ | ❌ |
| Upload tindak lanjut | ❌ | ❌ | ❌ | ✅ | ❌ |
| Tolak pengajuan (OPD) | ❌ | ❌ | ❌ | ✅ | ❌ |
| Approve tindak lanjut | ❌ | ❌ | ❌ | ❌ | ✅ |
| Kirim warning/teguran | ❌ | ❌ | ❌ | ❌ | ✅ |
| Bypass tahapan | ❌ | ❌ | ❌ | ❌ | ✅ |
| Kelola master data | ❌ | ❌ | ❌ | ❌ | ✅ |
| Kelola user/akun | ❌ | ❌ | ❌ | ❌ | ✅ |
| Import CSV | ❌ | ❌ | ❌ | ❌ | ✅ |
| Lihat laporan | ❌ | ❌ | ❌ | ❌ | ✅ |

---

## REVISI 2: MODUL BARU — LAYANAN DATA BALITA

### 2.1 Deskripsi Modul

Modul Layanan Data Balita adalah fitur **berdiri sendiri** (TIDAK terintegrasi ke pengajuan OPD) yang tersedia di dashboard akun Posyandu. Modul ini merupakan digitalisasi dari **Formulir Pemantauan Penimbangan Balita dan Imunisasi Posyandu Tahunan** yang selama ini diisi secara manual.

**Fungsi utama:**
1. Pendataan anak balita beserta data orang tua
2. Pencatatan penimbangan bulanan (berat badan, tinggi badan, lingkar kepala, status gizi, dll)
3. Pencatatan riwayat pemberian imunisasi
4. Catatan kesehatan balita (free text)
5. Data dari posyandu **otomatis masuk ke rekap desa** (petugas desa bisa lihat)

**Penting — Modul ini BUKAN pengajuan ke OPD:**
- Tidak ada alur verifikasi desa → OPD
- Tidak ada nomor tiket
- Tidak ada SOP timer
- Ini murni pencatatan data layanan kesehatan rutin posyandu

### 2.2 Hierarki Data Balita

```
Posyandu (akun)
└── Data Balita (banyak per posyandu)
    ├── Penimbangan Bulanan (12 record per tahun per balita)
    ├── Riwayat Imunisasi (banyak per balita)
    └── Catatan Kesehatan (free text per balita)
```

**Rekap ke atas:**
```
Posyandu → Desa (petugas desa lihat semua posyandu di desanya)
         → Kecamatan (petugas kecamatan lihat semua desa di kecamatannya)
         → Kabupaten (admin DPMD lihat semua)
```

### 2.3 Database Schema — Tabel Baru

```prisma
// =============================================
// MODUL LAYANAN DATA BALITA
// =============================================

model Balita {
  id             String   @id @default(uuid())
  posyanduId     String   @map("posyandu_id")      // relasi ke posyandu
  posyanduUserId String   @map("posyandu_user_id")  // relasi ke user akun posyandu yang menginput

  // Data Anak
  namaBalita     String   @map("nama_balita")
  tanggalLahir   DateTime @map("tanggal_lahir")
  jenisKelamin   JenisKelamin @map("jenis_kelamin")

  // Data Orang Tua
  namaOrangTua   String   @map("nama_orang_tua")    // nama ibu atau bapak
  nikOrangTua    String?  @map("nik_orang_tua")
  noHpOrangTua   String?  @map("no_hp_orang_tua")
  alamat         String?

  // Metadata
  tahunPencatatan Int     @map("tahun_pencatatan")   // tahun berjalan (misal: 2026)
  catatanKesehatan String? @map("catatan_kesehatan") // free text catatan kesehatan balita
  isActive       Boolean  @default(true) @map("is_active")
  createdAt      DateTime @default(now()) @map("created_at")
  updatedAt      DateTime @updatedAt @map("updated_at")

  // Relations
  posyandu       Posyandu          @relation(fields: [posyanduId], references: [id])
  posyanduUser   User              @relation("PosyanduBalita", fields: [posyanduUserId], references: [id])
  penimbangans   PenimbanganBalita[]
  imunisasis     ImunisasiBalita[]

  @@map("balitas")
}

enum JenisKelamin {
  LAKI_LAKI
  PEREMPUAN
}

model PenimbanganBalita {
  id             String   @id @default(uuid())
  balitaId       String   @map("balita_id")
  bulan          Int                               // 1-12 (Januari=1, Desember=12)
  tahun          Int                               // tahun penimbangan

  beratBadan     Float?   @map("berat_badan")      // dalam Kg
  tinggiBadan    Float?   @map("tinggi_badan")      // dalam Cm
  lingkarKepala  Float?   @map("lingkar_kepala")    // dalam Cm
  statusGizi     String?  @map("status_gizi")       // "Baik", "Kurang", "Buruk", "Lebih"
  keluhanKondisi String?  @map("keluhan_kondisi")   // keluhan atau kondisi saat penimbangan
  tindakan       String?                            // tindakan yang dilakukan
  namaKader      String?  @map("nama_kader")        // nama kader yang menimbang (free text)

  createdAt      DateTime @default(now()) @map("created_at")
  updatedAt      DateTime @updatedAt @map("updated_at")

  balita         Balita @relation(fields: [balitaId], references: [id], onDelete: Cascade)

  @@unique([balitaId, bulan, tahun])               // 1 balita hanya 1 record per bulan per tahun
  @@map("penimbangan_balitas")
}

model ImunisasiBalita {
  id               String   @id @default(uuid())
  balitaId         String   @map("balita_id")
  jenisImunisasi   String   @map("jenis_imunisasi")  // BCG, Polio, DPT, Campak, dll
  tanggalPemberian DateTime @map("tanggal_pemberian")
  usiaAnak         String?  @map("usia_anak")         // "2 bulan", "9 bulan", dll (free text)
  namaPetugas      String?  @map("nama_petugas")      // nama petugas yang memberikan
  keterangan       String?
  createdAt        DateTime @default(now()) @map("created_at")
  updatedAt        DateTime @updatedAt @map("updated_at")

  balita           Balita @relation(fields: [balitaId], references: [id], onDelete: Cascade)

  @@map("imunisasi_balitas")
}
```

### 2.4 Perubahan Model Prisma — Relasi Baru

Tambahkan relasi ke model `User` dan `Posyandu` yang sudah ada:

```prisma
// Tambah di model User:
balitas  Balita[] @relation("PosyanduBalita")

// Tambah di model Posyandu:
balitas  Balita[]
```

### 2.5 API Routes — Modul Balita

```
// === Data Balita (POSYANDU only, kecuali view untuk desa/kecamatan/admin) ===
GET    /api/balita                          → List balita milik posyandu yang login
POST   /api/balita                          → Tambah data balita baru
GET    /api/balita/:id                      → Detail balita + penimbangan + imunisasi
PATCH  /api/balita/:id                      → Edit data balita
DELETE /api/balita/:id                      → Hapus/nonaktifkan data balita (soft delete)

// === Penimbangan Bulanan ===
GET    /api/balita/:id/penimbangan          → List semua penimbangan balita
POST   /api/balita/:id/penimbangan          → Input penimbangan bulan tertentu
PATCH  /api/balita/:id/penimbangan/:penimbanganId → Edit penimbangan
DELETE /api/balita/:id/penimbangan/:penimbanganId → Hapus penimbangan

// === Imunisasi ===
GET    /api/balita/:id/imunisasi            → List riwayat imunisasi
POST   /api/balita/:id/imunisasi            → Tambah record imunisasi
PATCH  /api/balita/:id/imunisasi/:imunisasiId → Edit imunisasi
DELETE /api/balita/:id/imunisasi/:imunisasiId → Hapus imunisasi

// === Rekap (view only — untuk petugas desa, kecamatan, admin) ===
GET    /api/rekap/balita/desa/:desaId       → Rekap semua balita dari posyandu di desa
GET    /api/rekap/balita/kecamatan/:kecId   → Rekap balita di kecamatan
GET    /api/rekap/balita/all                → Rekap seluruh kabupaten (ADMIN_DPMD only)
```

**Aturan data scoping:**
- `POSYANDU` → hanya akses data balita milik posyandunya sendiri (`posyanduUserId = session.user.id`)
- `PETUGAS_DESA` → view only, melihat rekap dari semua posyandu di desanya
- `PETUGAS_KECAMATAN` → view only, melihat rekap dari semua desa di kecamatannya
- `ADMIN_DPMD` → view only, melihat semua data

### 2.6 Spesifikasi Halaman — Modul Balita

---

#### A. Menu di Dashboard Posyandu

Dashboard posyandu sekarang punya **2 section utama**:

```
┌─────────────────────────────────────┐
│  Selamat datang, Posyandu Melati 👋 │
│  Desa Sukamaju — Kec. Rangkasbitung │
│  No. Registrasi: REG-2026-001      │
├─────────────────────────────────────┤
│                                     │
│  📊 RINGKASAN                       │
│  ┌──────┐ ┌──────┐ ┌──────┐        │
│  │Total │ │Proses│ │Selesai│        │
│  │ 15   │ │  3   │ │  10  │        │
│  └──────┘ └──────┘ └──────┘        │
│                                     │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                     │
│  📋 PENGAJUAN LAYANAN / ADUAN       │
│  Pilih OPD tujuan:                  │
│  ┌──────┐ ┌──────┐ ┌──────┐        │
│  │ 🎓   │ │ 🏥   │ │ 🔧   │        │
│  │Pendid│ │Keseha│ │ PUPR │        │
│  └──────┘ └──────┘ └──────┘        │
│  ┌──────┐ ┌──────┐ ┌──────┐        │
│  │ 🏠   │ │ 🛡️   │ │ ❤️   │        │
│  │Perkim│ │Satpol│ │Sosial│        │
│  └──────┘ └──────┘ └──────┘        │
│                                     │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                     │
│  👶 LAYANAN DATA BALITA    [Lihat→] │
│  ┌──────────────────────────────┐   │
│  │ Total Balita Terdaftar: 25   │   │
│  │ Sudah Ditimbang Bulan Ini: 20│   │
│  │ Belum Ditimbang: 5           │   │
│  └──────────────────────────────┘   │
│                                     │
└─────────────────────────────────────┘
```

---

#### B. Halaman Daftar Balita

**URL**: `/posyandu/balita`

**Elemen**:
1. **Header**: "Data Balita — Posyandu [Nama Posyandu]"
2. **Tombol**: "+ Tambah Data Balita" (primary, besar)
3. **Filter**: Tahun pencatatan (default: tahun berjalan), Pencarian nama
4. **List/Tabel Balita**:
   - Kolom: Nama Balita, Nama Orang Tua, Tanggal Lahir, Usia (hitung otomatis), Jenis Kelamin, Status Penimbangan Bulan Ini (✅ / ❌)
   - Klik baris → halaman detail balita
5. **Ringkasan di atas tabel**:
   - Total balita terdaftar
   - Sudah ditimbang bulan ini
   - Belum ditimbang bulan ini
6. **Pagination** (10 per halaman)

---

#### C. Halaman Tambah Data Balita

**URL**: `/posyandu/balita/tambah`

**Form**:
```
SECTION: DATA ANAK
- Nama Balita *           (text, WAJIB)
- Tanggal Lahir *         (date picker, WAJIB)
- Jenis Kelamin *         (radio: Laki-laki / Perempuan, WAJIB)

SECTION: DATA ORANG TUA
- Nama Orang Tua (Ibu/Bapak) * (text, WAJIB)
- NIK Orang Tua           (text, opsional, max 16 digit)
- No. HP Orang Tua         (text, opsional)
- Alamat                   (textarea, opsional)

SECTION: PENCATATAN
- Tahun Pencatatan *       (select tahun, default tahun berjalan, WAJIB)
- Catatan Kesehatan        (textarea, opsional)

TOMBOL:
[Batal]  [Simpan Data Balita]
```

---

#### D. Halaman Detail Balita + Penimbangan

**URL**: `/posyandu/balita/[balitaId]`

**Elemen**:
1. **Header**: Nama Balita, Usia (hitung otomatis), Jenis Kelamin
2. **Info Orang Tua**: Nama, NIK, No HP, Alamat
3. **Tombol**: "Edit Data Balita" (secondary)

4. **Tab: "Penimbangan Bulanan"** (default)
   - Filter: Tahun (default tahun berjalan)
   - Tabel 12 baris (Januari–Desember):

   | Bulan | Berat (Kg) | Tinggi (Cm) | Lingkar Kepala | Status Gizi | Keluhan | Tindakan | Kader | Aksi |
   |-------|-----------|-------------|----------------|------------|---------|----------|-------|------|
   | Januari | 8.5 | 72 | 43 | Baik | - | - | Siti | ✏️ |
   | Februari | - | - | - | - | - | - | - | ➕ |
   | ... | | | | | | | | |

   - Bulan yang **sudah diisi**: tampilkan data + tombol edit (✏️)
   - Bulan yang **belum diisi**: tampilkan tanda "-" + tombol tambah (➕)
   - Bulan yang **belum tiba** (misal sekarang Mei, maka Juni–Desember): tampilkan abu-abu, tidak bisa diisi
   - Klik ➕ atau ✏️ → **modal/inline form** penimbangan:

   ```
   FORM PENIMBANGAN BULAN [NAMA BULAN]:
   - Berat Badan (Kg) *       (number, WAJIB, desimal diizinkan)
   - Tinggi Badan (Cm) *      (number, WAJIB, desimal diizinkan)
   - Lingkar Kepala (Cm)      (number, opsional)
   - Status Gizi *            (select: Baik / Kurang / Buruk / Lebih, WAJIB)
   - Keluhan / Kondisi        (textarea, opsional)
   - Tindakan                 (textarea, opsional)
   - Nama Kader               (text, opsional — nama kader yang menimbang)

   [Batal] [Simpan]
   ```

5. **Tab: "Riwayat Imunisasi"**
   - Tabel riwayat imunisasi (unlimited rows)
   - Tombol "+ Tambah Imunisasi"
   - Kolom: No, Jenis Imunisasi, Tanggal Pemberian, Usia Anak, Petugas, Keterangan, Aksi (edit/hapus)
   - Klik tambah/edit → **modal form**:

   ```
   FORM IMUNISASI:
   - Jenis Imunisasi *        (select atau text: BCG, Polio 1, Polio 2, DPT 1, DPT 2, DPT 3,
                                Campak, Hepatitis B, dll — atau ketik manual)
   - Tanggal Pemberian *      (date picker, WAJIB)
   - Usia Anak                (text, opsional — "2 bulan", "9 bulan")
   - Nama Petugas             (text, opsional)
   - Keterangan               (textarea, opsional)

   [Batal] [Simpan]
   ```

6. **Catatan Kesehatan**: textarea yang bisa diedit langsung + tombol simpan

---

#### E. Halaman Rekap Balita — Petugas Desa

**URL**: `/petugas-desa/rekap-balita`

**Akses**: PETUGAS_DESA (view only — tidak bisa edit)

**Elemen**:
1. **Header**: "Rekap Data Balita — Desa [Nama Desa]"
2. **Ringkasan**:
   - Total posyandu di desa: [angka] (rata-rata 5)
   - Total balita terdaftar: [angka]
   - Sudah ditimbang bulan ini: [angka]
   - Belum ditimbang: [angka]
3. **Filter**: Posyandu (semua / pilih), Tahun
4. **Tabel rekap per posyandu**:

   | Posyandu | Total Balita | Ditimbang Bulan Ini | Belum | Status Gizi Baik | Kurang | Buruk |
   |----------|-------------|--------------------|----|-----------------|--------|-------|
   | Posyandu Melati | 25 | 20 | 5 | 18 | 1 | 1 |
   | Posyandu Mawar | 18 | 18 | 0 | 16 | 2 | 0 |

5. **Klik nama posyandu** → lihat daftar balita posyandu tersebut (view only)
6. **Klik nama balita** → lihat detail balita + penimbangan + imunisasi (view only)

---

#### F. Halaman Rekap Balita — Petugas Kecamatan

**URL**: `/kecamatan/rekap-balita`

**Akses**: PETUGAS_KECAMATAN (view only)

**Sama seperti rekap desa**, tetapi:
- Level lebih tinggi: rekap per **desa** di kecamatan
- Filter: Desa (semua / pilih), Posyandu, Tahun

   | Desa | Jumlah Posyandu | Total Balita | Ditimbang | Belum | Gizi Baik | Kurang | Buruk |
   |------|----------------|-------------|-----------|-------|-----------|--------|-------|
   | Sukamaju | 5 | 120 | 100 | 20 | 90 | 8 | 2 |

---

#### G. Halaman Rekap Balita — Admin DPMD

Tersedia di `/admin/rekap-balita`. Sama seperti kecamatan tapi level **kabupaten** (rekap per kecamatan).

---

### 2.7 Perubahan Navigasi Dashboard

**Dashboard Posyandu — Navigasi Mobile (Bottom Nav)**:
```
🏠 Beranda | 📋 Pengajuan | 👶 Balita | 👤 Akun
```

**Dashboard Posyandu — Sidebar Desktop**:
```
📊 Beranda
📋 Pengajuan Layanan
  └── Buat Pengajuan
  └── Riwayat Pengajuan
👶 Layanan Balita
  └── Data Balita
  └── Tambah Balita
👤 Akun Saya
```

**Dashboard Petugas Desa — Tambah menu**:
```
(menu existing)
📊 Beranda
✅ Verifikasi Pengajuan
👶 Rekap Balita           ← BARU
```

**Dashboard Petugas Kecamatan — Tambah menu**:
```
(menu existing)
📊 Monitoring Pengajuan
👶 Rekap Balita           ← BARU
```

**Dashboard Admin DPMD — Tambah menu**:
```
(menu existing)
📊 Beranda
📋 Pengajuan
📢 Teguran & Bypass
👶 Rekap Balita           ← BARU
📈 Laporan
⚙️ Master Data
```

---

### 2.8 Validasi Form Penimbangan

```typescript
// Zod schema untuk penimbangan
const penimbanganSchema = z.object({
  bulan: z.number().min(1).max(12),
  tahun: z.number().min(2020).max(2100),
  beratBadan: z.number().min(0.5).max(50),         // 0.5 - 50 Kg
  tinggiBadan: z.number().min(30).max(150),         // 30 - 150 Cm
  lingkarKepala: z.number().min(20).max(60).optional(), // 20 - 60 Cm
  statusGizi: z.enum(['Baik', 'Kurang', 'Buruk', 'Lebih']),
  keluhanKondisi: z.string().optional(),
  tindakan: z.string().optional(),
  namaKader: z.string().optional(),
});

// Validasi: bulan tidak boleh lebih dari bulan berjalan di tahun berjalan
// Validasi: unique constraint [balitaId, bulan, tahun] — tidak boleh double entry
```

---

## CATATAN PENTING UNTUK AI AGENT

### ⚠️ Hal-Hal yang Harus Diperhatikan Saat Implementasi Revisi

1. **GANTI semua referensi `KADER` menjadi `POSYANDU`** di seluruh codebase:
   - Enum `UserRole.KADER` → `UserRole.POSYANDU`
   - Route `/kader/` → `/posyandu/`
   - Field `kaderId` di tabel `pengajuans` → rename menjadi `posyanduUserId` (atau tetap `kaderId` dengan komentar bahwa ini sekarang merujuk ke akun posyandu, pilih salah satu pendekatan dan konsisten)
   - Semua teks UI yang menyebut "Kader" sebagai role → ganti ke "Posyandu" (misal: "Login sebagai Kader" → "Login sebagai Posyandu")

2. **Akun posyandu adalah shared account.** Implikasinya:
   - Tidak bisa melacak **individu kader** mana yang menginput pengajuan — yang tercatat hanya akun posyandu
   - Field `namaKader` di form penimbangan balita berupa **free text** (bukan relasi ke user) — karena kader tidak punya akun individual
   - Session login tidak merepresentasikan 1 orang, tapi 1 unit posyandu

3. **Modul Balita berdiri sendiri**, TIDAK terkait dengan modul pengajuan/pengaduan OPD:
   - Tidak ada nomor tiket untuk data balita
   - Tidak ada alur verifikasi desa → OPD
   - Tidak ada SOP timer
   - Tabel `balitas`, `penimbangan_balitas`, `imunisasi_balitas` **tidak berelasi** ke tabel `pengajuans`
   - Data balita hanya bisa diinput oleh akun posyandu yang memiliki data tersebut

4. **Rekap data balita ke atas** — pastikan data scoping benar:
   - Posyandu hanya lihat data balita miliknya (`posyanduUserId = session.user.id`)
   - Petugas Desa lihat semua balita dari posyandu yang `desaId`-nya sama dengan `user.desaId` → join `balitas → posyandus → desas`
   - Petugas Kecamatan lihat semua balita dari desa yang `kecamatanId`-nya sama → join `balitas → posyandus → desas → kecamatans`
   - Admin DPMD lihat semua

5. **Unique constraint penimbangan**: 1 balita hanya boleh punya 1 record penimbangan per bulan per tahun. Jika user mencoba menambah penimbangan di bulan yang sudah ada, tampilkan pesan: "Data penimbangan bulan [X] sudah ada. Gunakan tombol edit untuk mengubah."

6. **Bulan yang belum tiba tidak bisa diisi.** Jika sekarang bulan Mei 2026, maka penimbangan untuk Juni–Desember 2026 harus di-disable. Validasi ini harus ada di **frontend (disable tombol ➕)** dan **backend (reject API call)**.

7. **Jenis imunisasi**: Idealnya database-driven (admin bisa menambah jenis baru), tapi untuk V2 cukup hardcode list umum dengan opsi "Lainnya" (free text):
   - BCG
   - Polio 1, Polio 2, Polio 3, Polio 4
   - DPT-HB-Hib 1, DPT-HB-Hib 2, DPT-HB-Hib 3
   - Campak/MR 1, Campak/MR 2
   - Hepatitis B 0 (neonatal)
   - IPV 1, IPV 2
   - PCV 1, PCV 2, PCV 3
   - Rotavirus 1, Rotavirus 2, Rotavirus 3
   - Lainnya (free text)

8. **Field `noRegistrasi` di tabel users** harus:
   - Unique (tidak boleh duplikat)
   - Wajib diisi untuk role `POSYANDU`
   - Nullable untuk role lain
   - Ditampilkan di dashboard posyandu sebagai identitas

9. **Perubahan seed data**: Update `/prisma/seed.ts`:
   - Ganti user kader menjadi akun posyandu
   - Contoh: email/username "melati001", password "posyandu123", role POSYANDU
   - Tambahkan beberapa data balita contoh

10. **Laporan admin DPMD di V1 hanya untuk pengajuan.** Di V2, tambahkan section rekap balita di halaman laporan:
    - Total balita per desa/kecamatan
    - Persentase penimbangan bulan ini
    - Distribusi status gizi (pie chart)
    - Tren penimbangan per bulan (line chart)

---

## RINGKASAN SEMUA FILE/TABEL YANG BERUBAH

### Tabel Database
| Tabel | Status | Keterangan |
|-------|--------|------------|
| `users` | 🔄 DIUBAH | Tambah field `no_registrasi`, rename role KADER→POSYANDU |
| `pengajuans` | 🔄 DIUBAH | Rename `kader_id` → `posyandu_user_id` (opsional, bisa tetap `kader_id` dengan komentar) |
| `balitas` | 🆕 BARU | Data anak balita |
| `penimbangan_balitas` | 🆕 BARU | Penimbangan bulanan |
| `imunisasi_balitas` | 🆕 BARU | Riwayat imunisasi |

### Halaman / Route
| Halaman | Status | Keterangan |
|---------|--------|------------|
| `/kader/*` | 🔄 RENAME → `/posyandu/*` | Rename folder, update teks UI |
| `/posyandu/balita/*` | 🆕 BARU | 4 halaman baru modul balita |
| `/petugas-desa/rekap-balita` | 🆕 BARU | Rekap data balita per desa |
| `/kecamatan/rekap-balita` | 🆕 BARU | Rekap data balita per kecamatan |
| `/admin/rekap-balita` | 🆕 BARU | Rekap data balita kabupaten |

### API Routes
| Route | Status | Keterangan |
|-------|--------|------------|
| `/api/balita/*` | 🆕 BARU | CRUD data balita |
| `/api/balita/:id/penimbangan/*` | 🆕 BARU | CRUD penimbangan |
| `/api/balita/:id/imunisasi/*` | 🆕 BARU | CRUD imunisasi |
| `/api/rekap/balita/*` | 🆕 BARU | Rekap per desa/kecamatan/all |

---

**Versi Dokumen**: 2.0
**Tanggal**: 25 Mei 2026
**Status**: Final — Siap Implementasi
**Referensi**: Dokumen ini merupakan **addendum/revisi** terhadap `E-POSYANDU_DOKUMENTASI_TEKNIS.md` (V1). Baca kedua dokumen bersama untuk gambaran lengkap.
