# E-POSYANDU — DOKUMEN REVISI V3: MODUL PENDATAAN ANAK TIDAK SEKOLAH (ATS)
**Penambahan modul baru terhadap sistem E-Posyandu**
**Tanggal: 28 Mei 2026**

---

## RINGKASAN

Modul **Pendataan Anak Tidak Sekolah (ATS)** adalah fitur baru yang **berdiri sendiri** di dashboard akun Posyandu (sama seperti modul Balita). Modul ini merupakan digitalisasi dari formulir pendataan anak putus sekolah / tidak sekolah yang selama ini diisi secara manual oleh kader posyandu.

**Penting:**
- Modul ini **BUKAN** pengajuan ke OPD — tidak ada alur verifikasi, nomor tiket, atau SOP timer
- Modul ini **sejajar** dengan modul Balita — tersedia di dashboard posyandu sebagai menu terpisah
- Data dari posyandu **otomatis masuk ke rekap desa → kecamatan → kabupaten** (sama seperti modul Balita)

---

## 1. FIELD DATA ATS (BERDASARKAN FORMAT EXCEL)

Berikut adalah 22 field data yang harus diinput (berdasarkan file `Format_Pendataan_ATS.xlsx`):

### Section A — Data Anak

| No | Field | Nama Database | Tipe Input | Wajib | Validasi / Keterangan |
|----|-------|---------------|------------|-------|----------------------|
| 1 | Nama Anak | `nama_anak` | text | ✅ Ya | - |
| 2 | NIK | `nik` | text | ❌ Tidak | Maks 16 digit angka |
| 3 | Jenis Kelamin | `jenis_kelamin` | radio | ✅ Ya | Pilihan: `Laki-laki` / `Perempuan` |
| 4 | Tempat Lahir | `tempat_lahir` | text | ✅ Ya | - |
| 5 | Tanggal Lahir | `tanggal_lahir` | date picker | ✅ Ya | Tidak boleh lebih dari hari ini |
| 6 | Usia | `usia` | **auto-hitung** | — | Dihitung otomatis dari tanggal lahir. Tidak perlu input manual. Tampilkan sebagai "[X] tahun" |
| 7 | Alamat | `alamat` | textarea | ✅ Ya | Alamat lengkap (Kampung/Jalan) |
| 8 | RT/RW | `rt_rw` | text | ❌ Tidak | Format bebas, contoh: "001/002" |

### Section B — Data Wilayah

| No | Field | Nama Database | Tipe Input | Wajib | Validasi / Keterangan |
|----|-------|---------------|------------|-------|----------------------|
| 9 | Desa/Kelurahan | `desa_id` | **auto-fill** | — | Otomatis dari akun posyandu yang login (relasi posyandu → desa). Tampilkan nama desa, simpan ID. |
| 10 | Kecamatan | `kecamatan_id` | **auto-fill** | — | Otomatis dari relasi desa → kecamatan. Tampilkan nama kecamatan, simpan ID. |
| 11 | Kabupaten/Kota | — | **auto-fill** | — | Selalu "Lebak". Tampilkan saja, tidak perlu simpan di database (sudah fixed). |

### Section C — Data Orang Tua / Wali

| No | Field | Nama Database | Tipe Input | Wajib | Validasi / Keterangan |
|----|-------|---------------|------------|-------|----------------------|
| 12 | Nama Orang Tua/Wali | `nama_orang_tua` | text | ✅ Ya | - |
| 13 | Pekerjaan Orang Tua | `pekerjaan_orang_tua` | text | ❌ Tidak | Free text (Petani, Buruh, Pedagang, dll) |
| 14 | No. HP Orang Tua | `no_hp_orang_tua` | text | ❌ Tidak | Format nomor Indonesia |

### Section D — Riwayat Pendidikan

| No | Field | Nama Database | Tipe Input | Wajib | Validasi / Keterangan |
|----|-------|---------------|------------|-------|----------------------|
| 15 | Pendidikan Terakhir | `pendidikan_terakhir` | select | ✅ Ya | Pilihan: `Tidak Sekolah`, `PAUD/TK`, `SD/MI`, `SMP/MTs`, `SMA/MA/SMK` |
| 16 | Kelas Terakhir | `kelas_terakhir` | text | ❌ Tidak | Free text: "Kelas 3", "Kelas 6", dll |
| 17 | Status Sekolah | `status_sekolah` | select | ✅ Ya | Pilihan: `Putus Sekolah`, `Tidak Pernah Sekolah`, `Lulus Tidak Melanjutkan` |
| 18 | Alasan Tidak Sekolah | `alasan_tidak_sekolah` | select + text | ✅ Ya | Pilihan: `Ekonomi`, `Jarak Sekolah Jauh`, `Bekerja/Membantu Orang Tua`, `Menikah Dini`, `Disabilitas`, `Tidak Ada Motivasi`, `Lainnya` → jika "Lainnya" muncul text input tambahan |
| 19 | Tahun Putus Sekolah | `tahun_putus_sekolah` | select tahun | ❌ Tidak | Pilihan: tahun 2015 s/d tahun berjalan. Kosongkan jika tidak pernah sekolah. |

### Section E — Kebutuhan & Tindak Lanjut

| No | Field | Nama Database | Tipe Input | Wajib | Validasi / Keterangan |
|----|-------|---------------|------------|-------|----------------------|
| 20 | Keinginan Kembali Sekolah | `keinginan_sekolah` | radio | ✅ Ya | Pilihan: `Ya`, `Tidak`, `Ragu-ragu` |
| 21 | Program yang Dibutuhkan | `program_dibutuhkan` | checkbox (multi) | ❌ Tidak | Pilihan (bisa pilih lebih dari 1): `Paket A`, `Paket B`, `Paket C`, `Kursus Keterampilan`, `Beasiswa`, `Pendampingan`, `Lainnya` → jika "Lainnya" muncul text input tambahan |
| 22 | Keterangan | `keterangan` | textarea | ❌ Tidak | Free text, catatan tambahan |

---

## 2. DATABASE SCHEMA

### Tabel Baru: `anak_tidak_sekolahs`

```prisma
model AnakTidakSekolah {
  id                   String   @id @default(uuid())
  posyanduId           String   @map("posyandu_id")
  posyanduUserId       String   @map("posyandu_user_id")  // akun posyandu yang menginput

  // === Section A: Data Anak ===
  namaAnak             String   @map("nama_anak")
  nik                  String?
  jenisKelamin         JenisKelamin @map("jenis_kelamin")  // gunakan enum yang sudah ada dari modul Balita
  tempatLahir          String   @map("tempat_lahir")
  tanggalLahir         DateTime @map("tanggal_lahir")
  // usia: TIDAK disimpan di DB — dihitung otomatis dari tanggalLahir
  alamat               String
  rtRw                 String?  @map("rt_rw")

  // === Section B: Data Wilayah (auto-fill dari akun posyandu) ===
  desaId               String   @map("desa_id")
  kecamatanId          String   @map("kecamatan_id")

  // === Section C: Data Orang Tua ===
  namaOrangTua         String   @map("nama_orang_tua")
  pekerjaanOrangTua    String?  @map("pekerjaan_orang_tua")
  noHpOrangTua         String?  @map("no_hp_orang_tua")

  // === Section D: Riwayat Pendidikan ===
  pendidikanTerakhir   String   @map("pendidikan_terakhir")   // "Tidak Sekolah", "PAUD/TK", "SD/MI", "SMP/MTs", "SMA/MA/SMK"
  kelasTerakhir        String?  @map("kelas_terakhir")        // free text: "Kelas 3", "Kelas 6"
  statusSekolah        String   @map("status_sekolah")        // "Putus Sekolah", "Tidak Pernah Sekolah", "Lulus Tidak Melanjutkan"
  alasanTidakSekolah   String   @map("alasan_tidak_sekolah")  // "Ekonomi", "Jarak Sekolah Jauh", dll
  alasanLainnya        String?  @map("alasan_lainnya")        // free text jika alasan = "Lainnya"
  tahunPutusSekolah    Int?     @map("tahun_putus_sekolah")

  // === Section E: Kebutuhan & Tindak Lanjut ===
  keinginanSekolah     String   @map("keinginan_sekolah")     // "Ya", "Tidak", "Ragu-ragu"
  programDibutuhkan    Json?    @map("program_dibutuhkan")    // JSON array string: ["Paket A", "Beasiswa"]
  programLainnya       String?  @map("program_lainnya")       // free text jika pilih "Lainnya"
  keterangan           String?

  // === Metadata ===
  isActive             Boolean  @default(true) @map("is_active")
  createdAt            DateTime @default(now()) @map("created_at")
  updatedAt            DateTime @updatedAt @map("updated_at")

  // === Relations ===
  posyandu             Posyandu  @relation(fields: [posyanduId], references: [id])
  posyanduUser         User      @relation("PosyanduATS", fields: [posyanduUserId], references: [id])
  desa                 Desa      @relation(fields: [desaId], references: [id])
  kecamatan            Kecamatan @relation(fields: [kecamatanId], references: [id])

  @@map("anak_tidak_sekolahs")
}
```

### Relasi Baru yang Harus Ditambahkan ke Model Existing

```prisma
// Tambah di model User:
atsRecords  AnakTidakSekolah[] @relation("PosyanduATS")

// Tambah di model Posyandu:
atsRecords  AnakTidakSekolah[]

// Tambah di model Desa:
atsRecords  AnakTidakSekolah[]

// Tambah di model Kecamatan:
atsRecords  AnakTidakSekolah[]
```

---

## 3. API ROUTES

```
// === CRUD Data ATS (POSYANDU only untuk create/edit/delete) ===
GET    /api/ats                         → List ATS milik posyandu yang login
POST   /api/ats                         → Tambah data ATS baru
GET    /api/ats/:id                     → Detail data ATS
PATCH  /api/ats/:id                     → Edit data ATS
DELETE /api/ats/:id                     → Hapus/nonaktifkan (soft delete via isActive=false)

// === Rekap (view only — untuk petugas desa, kecamatan, admin) ===
GET    /api/rekap/ats/desa/:desaId          → Rekap ATS dari semua posyandu di desa
GET    /api/rekap/ats/kecamatan/:kecId      → Rekap ATS dari semua desa di kecamatan
GET    /api/rekap/ats/all                   → Rekap seluruh kabupaten (ADMIN_DPMD only)

// === Export ===
GET    /api/rekap/ats/export?level=desa&id=xxx&format=xlsx  → Export data ke Excel
GET    /api/rekap/ats/export?level=kecamatan&id=xxx&format=xlsx
GET    /api/rekap/ats/export?level=all&format=xlsx
```

### Data Scoping (Sama Seperti Modul Balita)
- `POSYANDU` → hanya akses data ATS milik posyandunya (`posyanduUserId = session.user.id`)
- `PETUGAS_DESA` → view only, rekap semua posyandu di desanya
- `PETUGAS_KECAMATAN` → view only, rekap semua desa di kecamatannya
- `ADMIN_DPMD` → view only, lihat semua + export

---

## 4. SPESIFIKASI HALAMAN

### 4.1 Perubahan Dashboard Posyandu

Tambahkan 1 section baru di bawah modul Balita:

```
┌─────────────────────────────────────┐
│  ...                                │
│  (6 card OPD — sudah ada)           │
│  (Section Balita — sudah ada)       │
│                                     │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                     │
│  🎓 PENDATAAN ANAK TIDAK SEKOLAH   │
│  ┌──────────────────────────────┐   │
│  │ Total ATS Terdaftar: 12     │   │
│  │ Putus Sekolah: 8            │   │
│  │ Tidak Pernah Sekolah: 3     │   │
│  │ Lulus Tidak Melanjutkan: 1  │   │
│  └──────────────────────────────┘   │
│  [Lihat Data ATS →]                │
│                                     │
└─────────────────────────────────────┘
```

### 4.2 Perubahan Navigasi

**Navigasi Mobile (Bottom Nav) — Posyandu:**
```
🏠 Beranda | 📋 Pengajuan | 👶 Balita | 🎓 ATS | 👤 Akun
```

**Sidebar Desktop — Posyandu:**
```
📊 Beranda
📋 Pengajuan Layanan
  └── Buat Pengajuan
  └── Riwayat Pengajuan
👶 Layanan Balita
  └── Data Balita
  └── Tambah Balita
🎓 Pendataan ATS              ← BARU
  └── Data ATS
  └── Tambah Data ATS
👤 Akun Saya
```

**Sidebar Petugas Desa — Tambah:**
```
👶 Rekap Balita
🎓 Rekap ATS                  ← BARU
```

**Sidebar Petugas Kecamatan — Tambah:**
```
👶 Rekap Balita
🎓 Rekap ATS                  ← BARU
```

**Sidebar Admin DPMD — Tambah:**
```
👶 Rekap Balita
🎓 Rekap ATS                  ← BARU
```

### 4.3 Halaman Daftar ATS

**URL**: `/posyandu/ats`

**Elemen**:
1. **Header**: "Pendataan Anak Tidak Sekolah — Posyandu [Nama]"
2. **Tombol**: "+ Tambah Data ATS" (primary, besar, full-width di mobile)
3. **Ringkasan** (4 kartu kecil):
   - Total ATS Terdaftar
   - Putus Sekolah
   - Tidak Pernah Sekolah
   - Lulus Tidak Melanjutkan
4. **Filter**: Pencarian nama, Status Sekolah, Pendidikan Terakhir
5. **Tabel/List**:

   | Nama Anak | Usia | Jenis Kelamin | Pendidikan Terakhir | Status | Alasan | Aksi |
   |-----------|------|---------------|--------------------|----|--------|------|
   | Ahmad Fauzi | 15 th | L | SD | Putus Sekolah | Ekonomi | 👁️ ✏️ 🗑️ |

   - Di **mobile**: tampilkan sebagai card list (bukan tabel), setiap card berisi info utama
   - 👁️ = lihat detail, ✏️ = edit, 🗑️ = hapus (dengan konfirmasi)
6. **Pagination**: 10 per halaman

### 4.4 Halaman Form Tambah/Edit Data ATS

**URL**: `/posyandu/ats/tambah` (tambah) atau `/posyandu/ats/[id]/edit` (edit)

**Layout form** dibagi dalam **5 section** dengan garis pemisah atau accordion yang bisa expand/collapse. Setiap section punya judul section agar mudah dibaca.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  📝 DATA ANAK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Nama Anak *
  [___________________________________]

  NIK
  [___________________________________]
  Maks 16 digit angka

  Jenis Kelamin *
  ○ Laki-laki   ○ Perempuan

  Tempat Lahir *
  [___________________________________]

  Tanggal Lahir *
  [📅 Pilih tanggal__________________ ]

  Usia: 15 tahun                        ← auto-hitung, tampilkan setelah tanggal lahir diisi

  Alamat *
  [___________________________________]
  [___________________________________]

  RT/RW
  [___________________________________]
  Contoh: 001/002

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  📍 DATA WILAYAH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Desa/Kelurahan : Cireundeu            ← auto-fill, read-only
  Kecamatan      : Cilograng            ← auto-fill, read-only
  Kabupaten/Kota : Lebak                ← auto-fill, read-only

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  👨‍👩‍👧 DATA ORANG TUA / WALI
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Nama Orang Tua / Wali *
  [___________________________________]

  Pekerjaan Orang Tua
  [___________________________________]

  No. HP Orang Tua
  [___________________________________]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  🎓 RIWAYAT PENDIDIKAN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Pendidikan Terakhir *
  [▼ Pilih pendidikan terakhir_______ ]
  Pilihan: Tidak Sekolah | PAUD/TK | SD/MI | SMP/MTs | SMA/MA/SMK

  Kelas Terakhir
  [___________________________________]
  Contoh: Kelas 3, Kelas 6

  Status Sekolah *
  [▼ Pilih status____________________ ]
  Pilihan: Putus Sekolah | Tidak Pernah Sekolah | Lulus Tidak Melanjutkan

  Alasan Tidak Sekolah *
  [▼ Pilih alasan____________________ ]
  Pilihan: Ekonomi | Jarak Sekolah Jauh | Bekerja/Membantu Orang Tua |
           Menikah Dini | Disabilitas | Tidak Ada Motivasi | Lainnya

  [Jika "Lainnya" dipilih, muncul:]
  Alasan Lainnya *
  [___________________________________]

  Tahun Putus Sekolah
  [▼ Pilih tahun_____________________ ]
  Pilihan: 2015 s/d tahun berjalan. Kosongkan jika tidak pernah sekolah.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  📋 KEBUTUHAN & TINDAK LANJUT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Keinginan Kembali Sekolah *
  ○ Ya   ○ Tidak   ○ Ragu-ragu

  Program yang Dibutuhkan
  ☐ Paket A
  ☐ Paket B
  ☐ Paket C
  ☐ Kursus Keterampilan
  ☐ Beasiswa
  ☐ Pendampingan
  ☐ Lainnya → [___________________]    ← muncul jika Lainnya dicentang

  Keterangan
  [___________________________________]
  [___________________________________]
  Catatan tambahan

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  [Batal]                [Simpan Data ATS]

  → Sebelum simpan: modal konfirmasi
  → Setelah simpan: redirect ke daftar ATS + toast "Data berhasil disimpan"
```

### 4.5 Halaman Detail ATS

**URL**: `/posyandu/ats/[id]`

**Elemen**:
1. Tampilkan semua data dalam format read-only, dikelompokkan per section (sama seperti form)
2. Usia dihitung otomatis dari tanggal lahir
3. Tombol "Edit" (secondary) dan "Hapus" (danger) di bagian bawah
4. Hapus: modal konfirmasi "Apakah Anda yakin ingin menghapus data ini?"

### 4.6 Halaman Rekap ATS — Petugas Desa

**URL**: `/petugas-desa/rekap-ats`

**Akses**: PETUGAS_DESA (view only)

**Elemen**:
1. **Header**: "Rekap Anak Tidak Sekolah — Desa [Nama Desa]"
2. **Ringkasan**:
   - Total ATS di desa
   - Per status: Putus Sekolah / Tidak Pernah Sekolah / Lulus Tidak Melanjutkan
   - Per alasan: Ekonomi, Jarak, dll (tampilkan top 3)
3. **Filter**: Posyandu (semua / pilih), Status, Pendidikan Terakhir
4. **Tabel rekap per posyandu**:

   | Posyandu | Total ATS | Putus Sekolah | Tidak Pernah | Lulus Tidak Lanjut |
   |----------|----------|---------------|--------------|--------------------|
   | Posyandu Melati | 12 | 8 | 3 | 1 |
   | Posyandu Mawar | 5 | 3 | 1 | 1 |

5. Klik nama posyandu → lihat daftar ATS posyandu tersebut (view only)
6. Klik nama anak → lihat detail (view only)
7. **Tombol Export Excel** — download data ATS desa sebagai file .xlsx

### 4.7 Halaman Rekap ATS — Petugas Kecamatan

**URL**: `/kecamatan/rekap-ats`

Sama seperti rekap desa, tapi level lebih tinggi — rekap per **desa** di kecamatan:

| Desa | Jumlah Posyandu | Total ATS | Putus Sekolah | Tidak Pernah | Lulus Tidak Lanjut |
|------|----------------|----------|---------------|--------------|--------------------|
| Cireundeu | 5 | 45 | 30 | 10 | 5 |

### 4.8 Halaman Rekap ATS — Admin DPMD

**URL**: `/admin/rekap-ats`

Level **kabupaten** — rekap per kecamatan. Ditambah:
- Chart distribusi alasan tidak sekolah (pie chart)
- Chart distribusi status sekolah (bar chart)
- Chart distribusi program yang dibutuhkan (horizontal bar chart)
- **Tombol Export Excel** — download semua data ATS kabupaten

---

## 5. STRUKTUR FOLDER BARU

```
/app/(dashboard)/posyandu/
  /ats/                            ← SELURUHNYA BARU
    page.tsx                       ← Daftar ATS
    /tambah/page.tsx               ← Form tambah
    /[atsId]/page.tsx              ← Detail ATS
    /[atsId]/edit/page.tsx         ← Form edit

/app/(dashboard)/petugas-desa/
  /rekap-ats/page.tsx              ← BARU

/app/(dashboard)/kecamatan/
  /rekap-ats/page.tsx              ← BARU

/app/(dashboard)/admin/
  /rekap-ats/page.tsx              ← BARU
```

---

## 6. VALIDASI FORM (ZOD SCHEMA)

```typescript
import { z } from 'zod';

export const atsSchema = z.object({
  // Section A: Data Anak
  namaAnak: z.string().min(1, "Nama anak wajib diisi"),
  nik: z.string()
    .max(16, "NIK maksimal 16 digit")
    .regex(/^\d*$/, "NIK hanya boleh berisi angka")
    .optional()
    .or(z.literal("")),
  jenisKelamin: z.enum(["LAKI_LAKI", "PEREMPUAN"], {
    required_error: "Jenis kelamin wajib dipilih"
  }),
  tempatLahir: z.string().min(1, "Tempat lahir wajib diisi"),
  tanggalLahir: z.date({
    required_error: "Tanggal lahir wajib diisi"
  }).refine(date => date <= new Date(), "Tanggal lahir tidak boleh lebih dari hari ini"),
  alamat: z.string().min(1, "Alamat wajib diisi"),
  rtRw: z.string().optional().or(z.literal("")),

  // Section C: Data Orang Tua
  namaOrangTua: z.string().min(1, "Nama orang tua wajib diisi"),
  pekerjaanOrangTua: z.string().optional().or(z.literal("")),
  noHpOrangTua: z.string().optional().or(z.literal("")),

  // Section D: Riwayat Pendidikan
  pendidikanTerakhir: z.enum(
    ["Tidak Sekolah", "PAUD/TK", "SD/MI", "SMP/MTs", "SMA/MA/SMK"],
    { required_error: "Pendidikan terakhir wajib dipilih" }
  ),
  kelasTerakhir: z.string().optional().or(z.literal("")),
  statusSekolah: z.enum(
    ["Putus Sekolah", "Tidak Pernah Sekolah", "Lulus Tidak Melanjutkan"],
    { required_error: "Status sekolah wajib dipilih" }
  ),
  alasanTidakSekolah: z.enum(
    ["Ekonomi", "Jarak Sekolah Jauh", "Bekerja/Membantu Orang Tua",
     "Menikah Dini", "Disabilitas", "Tidak Ada Motivasi", "Lainnya"],
    { required_error: "Alasan tidak sekolah wajib dipilih" }
  ),
  alasanLainnya: z.string().optional().or(z.literal("")),
  tahunPutusSekolah: z.number()
    .min(2015)
    .max(new Date().getFullYear())
    .optional()
    .nullable(),

  // Section E: Kebutuhan
  keinginanSekolah: z.enum(["Ya", "Tidak", "Ragu-ragu"], {
    required_error: "Keinginan sekolah wajib dipilih"
  }),
  programDibutuhkan: z.array(
    z.enum(["Paket A", "Paket B", "Paket C", "Kursus Keterampilan",
            "Beasiswa", "Pendampingan", "Lainnya"])
  ).optional(),
  programLainnya: z.string().optional().or(z.literal("")),
  keterangan: z.string().optional().or(z.literal("")),
})
// Cross-field validation:
.refine(
  data => data.alasanTidakSekolah !== "Lainnya" || (data.alasanLainnya && data.alasanLainnya.length > 0),
  { message: "Alasan lainnya wajib diisi jika memilih 'Lainnya'", path: ["alasanLainnya"] }
)
.refine(
  data => !(data.programDibutuhkan?.includes("Lainnya")) || (data.programLainnya && data.programLainnya.length > 0),
  { message: "Program lainnya wajib diisi jika memcentang 'Lainnya'", path: ["programLainnya"] }
);
```

---

## 7. CONDITIONAL FORM LOGIC

Berikut logic tampilan kondisional yang harus diimplementasikan di form:

| Kondisi | Aksi |
|---------|------|
| Tanggal lahir diisi | Tampilkan usia (auto-hitung) di bawah field tanggal lahir |
| Alasan Tidak Sekolah = "Lainnya" | Tampilkan field "Alasan Lainnya" (text, wajib) |
| Alasan Tidak Sekolah ≠ "Lainnya" | Sembunyikan field "Alasan Lainnya" |
| Program Dibutuhkan centang "Lainnya" | Tampilkan field "Program Lainnya" (text, wajib) |
| Program Dibutuhkan tidak centang "Lainnya" | Sembunyikan field "Program Lainnya" |
| Status Sekolah = "Tidak Pernah Sekolah" | Disable/hide field "Kelas Terakhir" dan "Tahun Putus Sekolah" |
| Pendidikan Terakhir = "Tidak Sekolah" | Otomatis set Status Sekolah = "Tidak Pernah Sekolah" |

---

## 8. EXPORT EXCEL

Format export harus **mengikuti format asli** dari file `Format_Pendataan_ATS.xlsx` yang diberikan client. Kolom export (urutan A–W):

```
A: No (nomor urut, auto-increment)
B: Nama Anak
C: NIK
D: Jenis Kelamin
E: Tempat Lahir
F: Tanggal Lahir (format: DD-MM-YYYY)
G: Usia (hitung otomatis)
H: Alamat
I: RT/RW
J: Desa/Kelurahan (nama, bukan ID)
K: Kecamatan (nama, bukan ID)
L: Kabupaten/Kota (selalu "Lebak")
M: Nama Orang Tua/Wali
N: Pekerjaan Orang Tua
O: No. HP Orang Tua
P: Pendidikan Terakhir
Q: Kelas Terakhir
R: Status Sekolah
S: Alasan Tidak Sekolah (jika "Lainnya", gabungkan: "Lainnya: [isi alasan]")
T: Tahun Putus Sekolah
U: Keinginan Kembali Sekolah
V: Program yang Dibutuhkan (gabungkan array jadi string pisah koma, contoh: "Paket A, Beasiswa")
W: Keterangan
```

**Library**: gunakan `xlsx` (SheetJS) atau `exceljs` di Next.js API route untuk generate file.

---

## 9. CATATAN IMPLEMENTASI UNTUK AI AGENT

### ⚠️ Perhatikan hal-hal berikut:

1. **Usia TIDAK disimpan di database.** Usia dihitung otomatis dari `tanggalLahir` menggunakan fungsi helper:
   ```typescript
   function hitungUsia(tanggalLahir: Date): number {
     const today = new Date();
     let usia = today.getFullYear() - tanggalLahir.getFullYear();
     const m = today.getMonth() - tanggalLahir.getMonth();
     if (m < 0 || (m === 0 && today.getDate() < tanggalLahir.getDate())) usia--;
     return usia;
   }
   ```

2. **Data wilayah (Desa, Kecamatan, Kabupaten) di-auto-fill** dari akun posyandu yang login. User TIDAK boleh mengubah field ini. Di backend, isi `desaId` dan `kecamatanId` dari relasi akun posyandu, BUKAN dari input user (mencegah manipulasi).

3. **`programDibutuhkan` disimpan sebagai JSON array** di kolom `Json` Prisma. Contoh value: `["Paket A", "Beasiswa", "Pendampingan"]`. Saat tampilkan di UI, parse JSON dan tampilkan sebagai list atau badge.

4. **Conditional field "Lainnya"**: Pastikan validasi cross-field berjalan di frontend DAN backend. Jika `alasanTidakSekolah = "Lainnya"` tapi `alasanLainnya` kosong, tolak request.

5. **Conditional field "Tidak Pernah Sekolah"**: Jika `statusSekolah = "Tidak Pernah Sekolah"`, maka `kelasTerakhir` dan `tahunPutusSekolah` harus **dikosongkan dan di-disable** di frontend. Di backend, set kedua field ini ke `null` jika status = "Tidak Pernah Sekolah".

6. **Soft delete**: Hapus data ATS menggunakan `isActive = false`, bukan delete permanen. Data yang `isActive = false` tidak muncul di list tapi masih ada di database.

7. **Export mengikuti format Excel asli client** (23 kolom A–W). Header row harus persis sama dengan template. Ini penting karena client akan membandingkan output sistem dengan formulir manual mereka.

8. **Modul ATS sejajar dengan modul Balita** — keduanya ada di dashboard posyandu, keduanya berdiri sendiri, keduanya punya rekap ke atas (desa → kecamatan → kabupaten). Arsitektur, pola akses data, dan navigasi harus konsisten antara keduanya.

9. **Mobile-first**: Form ATS panjang (22 field). Di mobile, gunakan section accordion atau step wizard agar user tidak overwhelmed scroll panjang. Rekomendasi: **accordion per section** (5 section, user klik untuk expand) dengan indikator section yang sudah terisi ✅.

10. **Permission matrix — modul ATS**:

    | Fitur | POSYANDU | PETUGAS_DESA | PETUGAS_KECAMATAN | PETUGAS_OPD | ADMIN_DPMD |
    |-------|----------|--------------|-------------------|-------------|------------|
    | Tambah data ATS | ✅ | ❌ | ❌ | ❌ | ❌ |
    | Edit data ATS | ✅ (miliknya) | ❌ | ❌ | ❌ | ❌ |
    | Hapus data ATS | ✅ (miliknya) | ❌ | ❌ | ❌ | ❌ |
    | Lihat daftar ATS | ✅ (miliknya) | ✅ (desanya) | ✅ (kecamatannya) | ❌ | ✅ (semua) |
    | Lihat detail ATS | ✅ (miliknya) | ✅ (desanya) | ✅ (kecamatannya) | ❌ | ✅ (semua) |
    | Export Excel | ❌ | ✅ | ✅ | ❌ | ✅ |

    **Catatan**: PETUGAS_OPD **tidak punya akses** ke modul ATS sama sekali.

---

## RINGKASAN FILE/TABEL YANG BERUBAH

### Tabel Database
| Tabel | Status | Keterangan |
|-------|--------|------------|
| `anak_tidak_sekolahs` | 🆕 BARU | Data anak tidak sekolah |
| `users` | 🔄 DIUBAH | Tambah relasi `atsRecords` |
| `posyandus` | 🔄 DIUBAH | Tambah relasi `atsRecords` |
| `desas` | 🔄 DIUBAH | Tambah relasi `atsRecords` |
| `kecamatans` | 🔄 DIUBAH | Tambah relasi `atsRecords` |

### Halaman / Route
| Halaman | Status |
|---------|--------|
| `/posyandu/ats/*` (4 halaman) | 🆕 BARU |
| `/petugas-desa/rekap-ats` | 🆕 BARU |
| `/kecamatan/rekap-ats` | 🆕 BARU |
| `/admin/rekap-ats` | 🆕 BARU |
| Dashboard posyandu | 🔄 DIUBAH — tambah section ATS |
| Navigasi sidebar semua role | 🔄 DIUBAH — tambah menu ATS |

### API Routes
| Route | Status |
|-------|--------|
| `/api/ats/*` | 🆕 BARU (5 endpoint) |
| `/api/rekap/ats/*` | 🆕 BARU (3 endpoint + 1 export) |

---

**Versi Dokumen**: 3.0
**Tanggal**: 28 Mei 2026
**Referensi**: Baca bersama dengan `E-POSYANDU_DOKUMENTASI_TEKNIS.md` (V1) dan `E-POSYANDU_REVISI_V2.md` (V2)
