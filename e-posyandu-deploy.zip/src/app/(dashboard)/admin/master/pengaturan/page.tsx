import { auth } from "@/auth"
import { redirect } from "next/navigation"
import { prisma } from "@/lib/prisma"
import { AppSettingsManager } from "@/components/admin/master/app-settings-manager"
import { defaultSlides } from "@/components/shared/ibu-bupati-slider"
import { PageHeader } from "@/components/shared/page-header"
import { PageContainer } from "@/components/layout/page-container"

export default async function PengaturanPage() {
  const session = await auth()
  if (!session?.user || session.user.role !== "ADMIN_DPMD") redirect("/login")

  const logoSetting = await prisma.appSetting.findUnique({ where: { key: "logo_url" } })
  const logoUrl = logoSetting?.value || null

  const sliderSetting = await prisma.appSetting.findUnique({ where: { key: "slider_photos" } })
  let sliderPhotos: { url: string; alt: string; caption?: string }[] = []
  if (sliderSetting?.value) {
    try {
      sliderPhotos = JSON.parse(sliderSetting.value)
    } catch {
      sliderPhotos = []
    }
  }
  // Belum pernah diatur → tampilkan foto default (Ibu PKK) agar tetap terkelola
  // saat admin menambah foto lain, bukan hilang tergantikan.
  if (sliderPhotos.length === 0) sliderPhotos = defaultSlides

  return (
    <PageContainer className="space-y-6">
      <PageHeader
        title="Pengaturan Aplikasi"
        description="Konfigurasi tampilan dan branding aplikasi E-Posyandu."
        backHref="/admin/master"
      />
      <div className="max-w-xl">
        <AppSettingsManager initialLogoUrl={logoUrl} initialSliderPhotos={sliderPhotos} />
      </div>
    </PageContainer>
  )
}
