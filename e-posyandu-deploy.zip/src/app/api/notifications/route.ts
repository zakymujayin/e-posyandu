import { prisma } from "@/lib/prisma"
import { requireAuth, ok, err } from "@/lib/api-helpers"
import { NextRequest } from "next/server"

export async function GET(_req: NextRequest) { // eslint-disable-line @typescript-eslint/no-unused-vars
  const { user, response } = await requireAuth()
  if (!user) return response!

  try {
    const notifications = await prisma.notification.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      take: 20,
      select: {
        id: true,
        type: true,
        title: true,
        message: true,
        isRead: true,
        createdAt: true,
        pengajuanId: true,
      },
    })

    const unreadCount = await prisma.notification.count({
      where: { userId: user.id, isRead: false },
    })

    return ok({ notifications, unreadCount })
  } catch (e) {
    console.error(e)
    return err("Gagal mengambil notifikasi", 500)
  }
}

export async function PATCH(_req: NextRequest) { // eslint-disable-line @typescript-eslint/no-unused-vars
  const { user, response } = await requireAuth()
  if (!user) return response!

  try {
    await prisma.notification.updateMany({
      where: { userId: user.id, isRead: false },
      data: { isRead: true, readAt: new Date() },
    })
    return ok(null, "Semua notifikasi ditandai sudah dibaca")
  } catch (e) {
    console.error(e)
    return err("Gagal memperbarui notifikasi", 500)
  }
}

export async function DELETE(_req: NextRequest) { // eslint-disable-line @typescript-eslint/no-unused-vars
  const { user, response } = await requireAuth()
  if (!user) return response!

  try {
    await prisma.notification.deleteMany({ where: { userId: user.id } })
    return ok(null, "Semua notifikasi dihapus")
  } catch (e) {
    console.error(e)
    return err("Gagal menghapus notifikasi", 500)
  }
}
