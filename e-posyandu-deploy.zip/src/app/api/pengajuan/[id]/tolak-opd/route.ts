import { z } from "zod"
import { prisma } from "@/lib/prisma"
import { requireAuth, ok, err } from "@/lib/api-helpers"
import { createNotificationsForUsers } from "@/lib/notifications"
import { sendStatusChangeEmail } from "@/lib/email"
import { stripHtml } from "@/lib/sanitize"

const schema = z.object({
  catatan: z.string().min(1, "Alasan penolakan wajib diisi").transform(stripHtml),
})

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user, response } = await requireAuth(["PETUGAS_OPD"])
  if (!user) return response!

  const { id } = await params
  const body = await req.json()
  const parsed = schema.safeParse(body)
  if (!parsed.success) return err(parsed.error.issues[0]?.message ?? "Data tidak valid")

  const pengajuan = await prisma.pengajuan.findUnique({
    where: { id },
    include: { posyanduUser: { select: { id: true, email: true, name: true } } },
  })

  if (!pengajuan) return err("Pengajuan tidak ditemukan", 404)
  if (pengajuan.status !== "DALAM_PROSES_OPD") {
    return err("Pengajuan tidak dalam status proses OPD")
  }

  if (user.opdId !== pengajuan.opdId) return err("Akses ditolak", 403)

  await prisma.$transaction(async (tx) => {
    await tx.pengajuan.update({
      where: { id },
      data: { status: "DITOLAK_OPD" },
    })
    await tx.activityLog.create({
      data: {
        pengajuanId: id,
        userId: user.id,
        userRole: "PETUGAS_OPD",
        action: "Pengajuan ditolak oleh OPD",
        oldStatus: "DALAM_PROSES_OPD",
        newStatus: "DITOLAK_OPD",
        catatan: parsed.data.catatan,
      },
    })
  })

  await createNotificationsForUsers([pengajuan.posyanduUserId], {
    type: "REJECTED_OPD",
    title: "Pengajuan Ditolak OPD",
    message: `Pengajuan ${pengajuan.tiketNumber} ditolak oleh OPD. Alasan: ${parsed.data.catatan}`,
    pengajuanId: id,
  })

  sendStatusChangeEmail(
    pengajuan.posyanduUser.email,
    pengajuan.posyanduUser.name,
    pengajuan.tiketNumber,
    "Ditolak OPD",
    id,
    "POSYANDU"
  ).catch((e) => console.error("[email] Failed to send status change:", e))

  return ok({ status: "DITOLAK_OPD" }, "Pengajuan berhasil ditolak")
}
